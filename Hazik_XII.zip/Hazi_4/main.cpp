#include <iostream>
#include <string.h>
using namespace std;
int main()
{
    int i,n,pos1=-1,pos2=-1,x;
    string forditott,szav,szav2,uj_szoveg;
    string szoveg;
    bool ok=false;
    getline(cin,szoveg);
    szoveg+=' ';
    for(i=0; i<szoveg.size(); i++)
    {
        if(szoveg[i]==' ')
        {
            pos1=pos2;
            pos2=i;
            //cout<<pos1 << "|" << pos2<<" " <<endl;
            if((pos2-pos1+1)%2==1)
            {
                forditott="";
                szav="";
                for(int k=pos2-1; k>pos1; k--)
                {
                    forditott+=szoveg[k];
                }
                for(int e=pos1+1; e<pos2; e++)
                {
                    szav+=szoveg[e];
                }
                if(szav==forditott)
                {
                    uj_szoveg+=szav;
                    uj_szoveg+=' ';
                }
                else
                {
                    uj_szoveg+=forditott;
                    uj_szoveg+=' ';
                    ok=true;
                }
            }
            else
            {
                szav2="";
                for (int x=pos1+1; x<pos2; x++)
                {
                    szav2+=szoveg[x];
                }
                uj_szoveg+=szav2;
                uj_szoveg+=' ';
            }
        }
    }
    if(!ok)
    {
        cout << "nu exista";
    }

    else
    {
        cout << uj_szoveg;
    }
    return 0;
}

