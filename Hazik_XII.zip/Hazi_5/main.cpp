#include <iostream>
#include <fstream>
using namespace std;

int main()
{
    int n,i,j;
    ifstream in("input.txt");
    ofstream out ("output.txt");
    float F=0,A=0,c1=0,c2=0;
    in >> n;
    int v[n][n];
    float atlag;
    for (i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            in >> v[i][j];
        }
    }
    for (i=0; i<n; i++)
    {
        for(j=0; j<n; j++)
        {
            if(i<j&& v[i][j]>0)
            {
                F+=v[i][j];
                c1++;

            }
            if(i>j&& v[i][j]>0)
            {
                A+=v[i][j];
                c2++;
            }
        }
    }
    //cout << F <<"|"<<A;
    atlag =(F/c1)-(A/c2);
    //cout << F/c1 <<"|"<<A/c2;
   out << atlag;
    return 0;
}
