#include <iostream>

using namespace std;

int main()
{
    int n,k,i=0,szam,counter,counter2=0,c;
    cout << "n = " ;
    cin >> n;
    cout << "k = ";
    cin >> k;
    for(i=1; i<=n; i++)
    {
        cout<<"szam = ";
        cin >> szam;
        counter=0;
        while(szam!=0)
        {
            c=szam%10;
            szam/=10;
            counter++;

        }
        if(counter > k)
        {
            counter2++;

        }
    }

    cout <<endl <<counter2<<endl;

    return 0;
}
