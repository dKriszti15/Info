#include <iostream>
using namespace std;

int main()
{
    int i,j,v[100],x[100],Sv=0,Sx=0,n;
    cout << "n=" ;
    cin>> n;
    for (i=0; i<n; i++)
    {
        cin >> v[i];
        if (v[i]%2==0)
        {
            Sv+=v[i];
        }
    }
    cout << endl;
    for (j=0; j<n; j++)
    {
        cin >> x[j];
        if(x[j]%2!=0)
        {
            if (x[j]<Sv)
            {
                Sx+=x[j];
            }
        }
    }
    cout << Sx;
    return 0;
}
